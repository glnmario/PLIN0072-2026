from otter.test_files import test_case

OK_FORMAT = False

name = "q9"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_closest_vectors_desc(line, ret_value, fn_name):
    test_strs = '''
def test_closest_vectors(closest_vectors, embeddings, word2index):
    paris_idx = word2index['paris']
    v_paris = embeddings[paris_idx, :]
    d = closest_vectors(embeddings, word2index, v_paris)
    target_paris = [('paris', 1.0), ('prohertrib', 0.803247675724159), ('france', 0.6580672325437251), ('french', 0.5986922910799846), ('brussels', 0.5912899013949027), ('london', 0.5776094084613798), ('strasbourg', 0.5281376806031204), ('parisian', 0.521298024663497), ('rome', 0.514927192691712), ('berlin', 0.5125114328991733)]
    for a, b in zip(d[:10], target_paris):
        w_a, dist_a = a
        w_b, dist_b = b
        assert w_a == w_b
        assert round(dist_a, 3) == round(dist_b, 3)
    austria_idx = word2index['austria']
    v_austria = embeddings[austria_idx, :]
    d2 = closest_vectors(embeddings, word2index, v_austria)
    target_austria = [('austria', 1.0000000000000002), ('austrian', 0.7418787064522784), ('germany', 0.662742495470577), ('switzerland', 0.6420188859681645), ('hungary', 0.6264760260946182), ('vienna', 0.584871351768602), ('finland', 0.5625376255066221), ('slovakia', 0.5516456126111633), ('salzburg', 0.5427258658161926), ('italy', 0.5375334941236511)]
    for a, b in zip(d2[:10], target_austria):
        w_a, dist_a = a
        w_b, dist_b = b
        assert w_a == w_b
        assert round(dist_a, 3) == round(dist_b, 3)
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_closest_vectors(closest_vectors, embeddings, word2index):
    paris_idx = word2index['paris']
    v_paris = embeddings[paris_idx, :]
    d = closest_vectors(embeddings, word2index, v_paris)
    target_paris = [('paris', 1.0), ('prohertrib', 0.803247675724159), ('france', 0.6580672325437251), ('french', 0.5986922910799846), ('brussels', 0.5912899013949027), ('london', 0.5776094084613798), ('strasbourg', 0.5281376806031204), ('parisian', 0.521298024663497), ('rome', 0.514927192691712), ('berlin', 0.5125114328991733)]
    for a, b in zip(d[:10], target_paris):
        w_a, dist_a = a
        w_b, dist_b = b
        assert w_a == w_b, test_closest_vectors_desc(8, w_a, "w_a")
        assert round(dist_a, 3) == round(dist_b, 3), test_closest_vectors_desc(9, round(dist_a, 3), "round(dist_a, 3)")
    austria_idx = word2index['austria']
    v_austria = embeddings[austria_idx, :]
    d2 = closest_vectors(embeddings, word2index, v_austria)
    target_austria = [('austria', 1.0000000000000002), ('austrian', 0.7418787064522784), ('germany', 0.662742495470577), ('switzerland', 0.6420188859681645), ('hungary', 0.6264760260946182), ('vienna', 0.584871351768602), ('finland', 0.5625376255066221), ('slovakia', 0.5516456126111633), ('salzburg', 0.5427258658161926), ('italy', 0.5375334941236511)]
    for a, b in zip(d2[:10], target_austria):
        w_a, dist_a = a
        w_b, dist_b = b
        assert w_a == w_b, test_closest_vectors_desc(17, w_a, "w_a")
        assert round(dist_a, 3) == round(dist_b, 3), test_closest_vectors_desc(18, round(dist_a, 3), "round(dist_a, 3)")

