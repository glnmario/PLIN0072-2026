from otter.test_files import test_case

OK_FORMAT = False

name = "q4"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_train_features_combined_desc(line, ret_value, fn_name):
    test_strs = '''
def test_train_features_combined(train_features_combined):
    assert train_features_combined.shape == (204579, 61575)
    assert train_features_combined.col[0] == 74
    assert train_features_combined.row[0] == 0
    assert train_features_combined.data[0] == 1
    assert train_features_combined.count_nonzero() == 30250766
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_train_features_combined(train_features_combined):
    assert train_features_combined.shape == (204579, 61575), test_train_features_combined_desc(1, train_features_combined.shape, "train_features_combined.shape")
    assert train_features_combined.col[0] == 74, test_train_features_combined_desc(2, train_features_combined.col[0], "train_features_combined.col[0]")
    assert train_features_combined.row[0] == 0, test_train_features_combined_desc(3, train_features_combined.row[0], "train_features_combined.row[0]")
    assert train_features_combined.data[0] == 1, test_train_features_combined_desc(4, train_features_combined.data[0], "train_features_combined.data[0]")
    assert train_features_combined.count_nonzero() == 30250766, test_train_features_combined_desc(5, train_features_combined.count_nonzero(), "train_features_combined.count_nonzero()")

