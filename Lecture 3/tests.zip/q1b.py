from otter.test_files import test_case

OK_FORMAT = False

name = "q1b"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_word2index_desc(line, ret_value, fn_name):
    test_strs = '''
def test_word2index(word2index):
    assert len(word2index) == 400000
    assert word2index['the'] == 0
    assert word2index['cat'] == 5450
    assert word2index['mat'] == 14948
    assert word2index['sat'] == 3223
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_word2index(word2index):
    assert len(word2index) == 400000, test_word2index_desc(1, len(word2index), "len(word2index)")
    assert word2index['the'] == 0, test_word2index_desc(2, word2index['the'], "word2index['the']")
    assert word2index['cat'] == 5450, test_word2index_desc(3, word2index['cat'], "word2index['cat']")
    assert word2index['mat'] == 14948, test_word2index_desc(4, word2index['mat'], "word2index['mat']")
    assert word2index['sat'] == 3223, test_word2index_desc(5, word2index['sat'], "word2index['sat']")

