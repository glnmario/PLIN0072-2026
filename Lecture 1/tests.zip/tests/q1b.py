from otter.test_files import test_case

OK_FORMAT = False

name = "q1b"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_dot_product_desc(line, ret_value, fn_name):
    test_strs = '''
def test_dot_product(dot_ab, dot_cd, dot_ef):
    assert dot_ab == 4
    assert dot_cd == -24
    assert dot_ef == -2
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_dot_product(dot_ab, dot_cd, dot_ef):
    assert dot_ab == 4, test_dot_product_desc(1, dot_ab, "dot_ab")
    assert dot_cd == -24, test_dot_product_desc(2, dot_cd, "dot_cd")
    assert dot_ef == -2, test_dot_product_desc(3, dot_ef, "dot_ef")

