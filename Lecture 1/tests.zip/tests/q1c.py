from otter.test_files import test_case

OK_FORMAT = False

name = "q1c"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_matmul_desc(line, ret_value, fn_name):
    test_strs = '''
def test_matmul(matmul_AB, matmul_CD, matmul_EF):
    assert matmul_AB == [[-3, -3, 7, -2], [-18, -18, -8, -2], [0, 0, -15, 3]]
    assert matmul_CD == [[4], [-2], [-6], [-14]]
    assert matmul_EF == [[-18, 6, -14]]
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_matmul(matmul_AB, matmul_CD, matmul_EF):
    assert matmul_AB == [[-3, -3, 7, -2], [-18, -18, -8, -2], [0, 0, -15, 3]], test_matmul_desc(1, matmul_AB, "matmul_AB")
    assert matmul_CD == [[4], [-2], [-6], [-14]], test_matmul_desc(2, matmul_CD, "matmul_CD")
    assert matmul_EF == [[-18, 6, -14]], test_matmul_desc(3, matmul_EF, "matmul_EF")

