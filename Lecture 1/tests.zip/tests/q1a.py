from otter.test_files import test_case

OK_FORMAT = False

name = "q1a"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_sizes_desc(line, ret_value, fn_name):
    test_strs = '''
def test_sizes(size_A, size_B, size_c, size_D, size_E, size_F):
    assert size_A == '5x2'
    assert size_B == '2x2'
    assert size_c == '7' or size_c == '7x1'
    assert size_D == '1x3'
    assert size_E == '4x6'
    assert size_F == '3x2'
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_sizes(size_A, size_B, size_c, size_D, size_E, size_F):
    assert size_A == '5x2', test_sizes_desc(1, size_A, "size_A")
    assert size_B == '2x2', test_sizes_desc(2, size_B, "size_B")
    assert size_c == '7' or size_c == '7x1', test_sizes_desc(3, size_c == '7' or size_c, "size_c == '7' or size_c")
    assert size_D == '1x3', test_sizes_desc(4, size_D, "size_D")
    assert size_E == '4x6', test_sizes_desc(5, size_E, "size_E")
    assert size_F == '3x2', test_sizes_desc(6, size_F, "size_F")

