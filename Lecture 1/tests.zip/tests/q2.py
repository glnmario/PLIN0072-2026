from otter.test_files import test_case

OK_FORMAT = False

name = "q2"
points = None

def format_error(lines, line, ret_value="", fn_name=""):
    return_str = "\n\n"
    return_str += "The last line of the following test program failed.\n"
    return_str += "Make sure that your function returns exactly the same value\n"
    return_str += "as specified in the <b>assert</b> statement.\n\n"

    num_spaces = len(lines[2]) - len(lines[2].strip()) 
    return_str += "\n".join([l[num_spaces:].strip() for l in lines[2:line+1]])
    return_str += "\n<b>"
    return_str += lines[line+1][num_spaces:]
    return_str += "</b>\n\n"

    return_str += f"{fn_name} returned:\n"
    return_str += str(ret_value)
    return_str += "\n\n"

    return return_str  




def test_np_defintions_desc(line, ret_value, fn_name):
    test_strs = '''
def test_np_defintions(A, B, C, D, E, F):
    assert A.tolist() == [[2, -1], [2, 4], [-3, 3]]
    assert B.tolist() == [[-3, -3, 2, -1], [-3, -3, -3, 0]]
    assert C.tolist() == [[-1, 4], [1, -3], [1, -5], [-3, -1]]
    assert D.tolist() == [[4], [2]]
    assert E.tolist() == [[-2, 4]]
    assert F.tolist() == [[1, -5, 1], [-4, -1, -3]]
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_np_defintions(A, B, C, D, E, F):
    assert A.tolist() == [[2, -1], [2, 4], [-3, 3]], test_np_defintions_desc(1, A.tolist(), "A.tolist()")
    assert B.tolist() == [[-3, -3, 2, -1], [-3, -3, -3, 0]], test_np_defintions_desc(2, B.tolist(), "B.tolist()")
    assert C.tolist() == [[-1, 4], [1, -3], [1, -5], [-3, -1]], test_np_defintions_desc(3, C.tolist(), "C.tolist()")
    assert D.tolist() == [[4], [2]], test_np_defintions_desc(4, D.tolist(), "D.tolist()")
    assert E.tolist() == [[-2, 4]], test_np_defintions_desc(5, E.tolist(), "E.tolist()")
    assert F.tolist() == [[1, -5, 1], [-4, -1, -3]], test_np_defintions_desc(6, F.tolist(), "F.tolist()")


def test_np_shapes_desc(line, ret_value, fn_name):
    test_strs = '''
def test_np_shapes(size_A, size_B, size_C):
    assert size_A == {'rows': 3, 'cols': 2}
    assert size_B == {'rows': 2, 'cols': 4}
    assert size_C == {'rows': 4, 'cols': 2}
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_np_shapes(size_A, size_B, size_C):
    assert size_A == {'rows': 3, 'cols': 2}, test_np_shapes_desc(1, size_A, "size_A")
    assert size_B == {'rows': 2, 'cols': 4}, test_np_shapes_desc(2, size_B, "size_B")
    assert size_C == {'rows': 4, 'cols': 2}, test_np_shapes_desc(3, size_C, "size_C")


def test_matmul_desc(line, ret_value, fn_name):
    test_strs = '''
def test_matmul(AB, CD, EF, BTD, C12D, A, B, C, D, E, F):
    import numpy as np
    assert AB.tolist() == np.matmul(A, B).tolist()
    assert CD.tolist() == np.matmul(C, D).tolist()
    assert EF.tolist() == np.matmul(E, F).tolist()
    assert BTD.tolist() == np.matmul(B.T, D).tolist()
    assert C12D.tolist() == np.matmul(C[0:2, :], D).tolist()
    '''.split("\n")
    return format_error(test_strs, line, ret_value, fn_name)


@test_case(points=None, hidden=False)
def test_matmul(AB, CD, EF, BTD, C12D, A, B, C, D, E, F):
    import numpy as np
    assert AB.tolist() == np.matmul(A, B).tolist(), test_matmul_desc(2, AB.tolist(), "AB.tolist()")
    assert CD.tolist() == np.matmul(C, D).tolist(), test_matmul_desc(3, CD.tolist(), "CD.tolist()")
    assert EF.tolist() == np.matmul(E, F).tolist(), test_matmul_desc(4, EF.tolist(), "EF.tolist()")
    assert BTD.tolist() == np.matmul(B.T, D).tolist(), test_matmul_desc(5, BTD.tolist(), "BTD.tolist()")
    assert C12D.tolist() == np.matmul(C[0:2, :], D).tolist(), test_matmul_desc(6, C12D.tolist(), "C12D.tolist()")

